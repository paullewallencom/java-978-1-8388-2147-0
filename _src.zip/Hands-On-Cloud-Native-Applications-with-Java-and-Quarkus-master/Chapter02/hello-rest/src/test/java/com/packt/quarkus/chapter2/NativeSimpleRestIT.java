package com.packt.quarkus.chapter2;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeSimpleRestIT extends SimpleRestTest {

    // Execute the same tests but in native mode.
}