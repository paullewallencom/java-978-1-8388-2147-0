package com.packt.chapter10;

import io.quarkus.runtime.annotations.RegisterForReflection;

@RegisterForReflection
public enum Company {
        Acme, Globex, Umbrella, Soylent, Initech
}


