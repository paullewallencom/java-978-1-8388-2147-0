package com.packt.chapter8;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeEndpointIT extends EndpointTest {

    // Execute the same tests but in native mode.
}