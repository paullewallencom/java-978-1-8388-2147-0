package com.packt.chapter8;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeExampleResourceIT extends AdvancedConfigTest {

    // Execute the same tests but in native mode.
}